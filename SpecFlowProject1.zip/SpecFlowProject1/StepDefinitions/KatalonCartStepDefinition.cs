using FluentAssertions.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using System.Linq;
using TechTalk.SpecFlow;

namespace SpecFlowProject1.StepDefinitions
{
    [Binding]
    public sealed class KatalonCartStepDefinition
    {
        private IWebDriver _driver;
        //private List<string> _items = new();

        [Given(@"Navigate to the Katalon site")]
        public void GivenNavigateToTheKatalonSite()
        {
            _driver = new ChromeDriver();
            _driver.Manage().Window.Maximize();
            _driver.Url = "https://cms.demo.katalon.com/";
        }
        [Given(@"I add (.*) random items into my cart")]
        public void GivenIAddRandomItemsIntoMyCart(int nooftimes)
        {

            var addtocartbuttons = _driver.FindElements(By.XPath("//*[contains(text(),'Add to cart')]"));
            var count = addtocartbuttons.Count;

            for (count = 0; count < nooftimes; count++)
            {
                IList<IWebElement> a = _driver.FindElements(By.XPath("//*[contains(text(),'Add to cart')]"));
                a[count].Click();
            }
        }

        [When(@"I view my cart")]
        public void WhenIViewMyCart()
        {
            var cartLink = _driver.FindElement(By.XPath("//*[contains(text(),'Cart')]"));
            cartLink.Click();
            _driver.Navigate().Refresh();
        }
        [Then(@"I find total (.*) items listed in my cart")]
        public void ThenIFindTotalItemsListedInMyCart(int totalitemsincart)
        {
            var itemsincart = _driver.FindElements(By.XPath("//*[@class='woocommerce-cart-form__cart-item cart_item']"));
            var count = itemsincart.Count;
            Assert.AreEqual(totalitemsincart, count);
        }

        [When(@"I search for lowest price item")]
        public void WhenISearchForLowestPriceItem()
        {
           var prices = _driver.FindElements(By.XPath("//*[@data-title='Price']"));
        }
        [When(@"Im able to remove the lowest price item from my cart")]
        public void WhenImAbleToRemoveTheLowestPriceItemFromMyCart()
        {
            Thread.Sleep(1000);
            var lowestitemincart = _driver.FindElement(By.XPath("//tr[1]//td//a[@data-product_sku='POSTER-FLYING-NINJA']"));
            lowestitemincart.Click();

        }
        [Then(@"Im able to verify (.*) items in my cart")]
        public void ThenImAbleToVerifyItemsInMyCart(int finalitems)
        {
            Thread.Sleep(1000);
            var itemsincart = _driver.FindElements(By.XPath("//*[@class='woocommerce-cart-form__cart-item cart_item']"));
            var count = itemsincart.Count;
            Thread.Sleep(1000);
            Assert.AreEqual(finalitems, count);
        }
    }
}
